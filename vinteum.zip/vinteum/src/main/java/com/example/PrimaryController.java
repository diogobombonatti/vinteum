package com.example;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

public class PrimaryController {

    @FXML
    private HBox mesaDoJogador;
    @FXML
    private HBox mesaDoComputador;
    @FXML
    private ImageView monte;

    @FXML
    private Label pontosMesa;
    @FXML
    private Label pontosJogador;
    @FXML
    private Label resultado;

    private Jogo jogo;

    public void turno() {
    try {
        if (!jogo.jogador.parou())
            jogo.distribuirCarta(jogo.jogador);
        if (!jogo.computador.parou()) {
            jogo.distribuirCarta(jogo.computador);
            if (jogo.jogador.parou())
                turno();
        }

        if (jogo.acabou()) {
            resultado.setText(jogo.resultado());
            JogoDao.inserir(jogo);
        }

        atualizar();
    } catch (Exception e) {
        // Trate a exceção aqui, você pode imprimir uma mensagem de erro ou fazer outra coisa adequada.
        e.printStackTrace();}
    }

    public void atualizar() {

    }

    public void novoJogo() {

    }

    public void pedirCarta() {
        turno();
    }

    public void parar() {

        turno();
    }

}
