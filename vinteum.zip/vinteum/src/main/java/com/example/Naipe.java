package com.example;

public enum Naipe {

    Hearts,
    Clubs,
    Diamonds,
    Spades


}