package com.example;

import java.sql.DriverManager;
import java.sql.SQLException;

public class JogoDao {
    final static String URL = "jdbc:mysql://auth-db719.hstgr.io:3306/u553405907_fiap";
    
    final static String USER = "u553405907_fiap";
    final static String PASS = "u553405907_FIAP";

    public static void inserir(Jogo jogo) throws SQLException {
        var conexao = DriverManager.getConnection(URL, USER, PASS);

        var sql = "INSERT INTO jogo (resultado) VALUES (?) ";
        var comando = conexao.prepareStatement(sql);
        
        comando.setString(1, jogo.resultado());
        

        conexao.close();

    }




}
